const express = require('express')
const bodyParser = require('body-parser')
const mysql = require("mysql"); 
const bcrypt = require('bcrypt');
var cors = require('cors');
const server = express();
server.use(bodyParser.json());

server.use(cors());    // cross origin



 
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "test",
});
db.connect(function (error) {
    if (error) {
      console.log("Error Connecting to DB");
    } else {
      console.log("successfully Connected to DB");
    }
  });

  server.listen(8085,function check(error) {
    if (error) 
    {
    console.log("Error....dddd!!!!");
    }
    else 
    {
        console.log("Started....!!!! 8085");
    }
});


//================================================== QUERY ================================


// insert records

const saltRounds = 10; // You can adjust the number of salt rounds as needed for security.

server.post("/api/employee/add", (req, res) => {
    
    const password = req.body.password;
     
  
    bcrypt.hash(password, saltRounds, (err, hash) => {
        if (err) {
            console.error(err);
            res.send({ status: false, message: "Error hashing password" });
        } else {
             
            req.body.password = hash;

            let details = {
                name: req.body.name,
                phonenumber: req.body.phonenumber,
                address: req.body.address,
                password: req.body.password,
                email: req.body.email,
                originalpass:req.body.originalpass
            };

            let sql = "INSERT INTO employee SET ?";
            db.query(sql, details, (error) => {
                if (error) {
                    res. send({ status: false, message: "Employee creation failed" });
                } else {
                    res.send({ status: true, message: "Employee created successfully" });
                    return;
                }
            });
        }
    });
  
});


// already employee exist check
function check(eml,pass){
  let email = eml
  let password = pass;

  // Retrieve the user from the database based on their email
  let sql = "SELECT * FROM employee WHERE email = ? || originalpass=?";
 
  db.query(sql, [email, password], (error, results) => {
      if (error) {
          res.send({ status: false, message: "Error connecting to the database" });
      } else {
          if (results.length === 0) {
             return false;
          } else { 
             
                 return true;
              
          }
      }
  });
}



//view the Records
server.get("/api/employee", (req, res) => {
    var sql = "SELECT * FROM employee";
    db.query(sql, function (error, result) {
      if (error) {
        console.log("Error Connecting to DB");
      } else {
        res.send({ status: true, data: result });
      }
    });
  });
//Search the Records
server.get("/api/employee/:id", (req, res) => {
    var employeeid = req.params.id;
    var sql = "SELECT * FROM employee WHERE id=" + employeeid;
    db.query(sql, function (error, result) {
      if (error) {
        console.log("Error Connecting to DB");
      } else {
        res.send({ status: true, data: result });
      }
    });
  });
  



//Update the Records
server.put("/api/employee/update/:id", (req, res) => {
    let sql =
      "UPDATE employee SET name='" +
      req.body.name +
      "', phonenumber='" +
      req.body.phonenumber +
      "', address='" +
      req.body.address + 
      "', originalpass='" +
      req.body.originalpass + 
      "',email='" +
      req.body.email +
      "'  WHERE id=" +
      req.params.id;
  
    let a = db.query(sql, (error, result) => {
      if (error) {
        res.send({ status: false, messemail: "employee Updated Failed" });
      } else {
        res.send({ status: true, messemail: "employee Updated successfully" });
      }
    });
  });
  //Delete the Records
  server.delete("/api/employee/delete/:id", (req, res) => {
    let sql = "DELETE FROM employee WHERE id=" + req.params.id + "";
    let query = db.query(sql, (error) => {
      if (error) {
        res.send({ status: false, messemail: "employee Deleted Failed" });
      } else {
        res.send({ status: true, messemail: "employee Deleted successfully" });
      }
    });
  });




// login auth
  
server.post("/api/employee/login", (req, res) => {
  const email = req.body.email;
  const password = req.body.originalpass;

  // Retrieve the user from the database based on their email
  let sql = "SELECT * FROM employee WHERE email = ? && originalpass=?";
 
  db.query(sql, [email, password], (error, results) => {
      if (error) {
          res.status(500).send({ status: false, message: "Error connecting to the database" });
      } else {
          if (results.length === 0) {
              res. send({ status: false, message: "User not found" });
          } else { 
             
                  res.send({ status: true, message: "Success" });
              
          }
      }
  });
});




 

